import { useState, useEffect } from 'react';

export default function Cart() {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    // Load cart from localStorage
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  const removeFromCart = (productId) => {
    const updatedCart = cartItems.filter(item => item.id !== productId);
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      
      {cartItems.length > 0 ? (
        <div>
          <div className="space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-semibold">{item.name}</h3>
                  <p className="text-gray-600">Quantity: {item.quantity}</p>
                  <p className="text-lg font-bold">${item.price}</p>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
          
          <div className="mt-8 border-t pt-4">
            <p className="text-2xl font-bold">Total: ${getTotalPrice()}</p>
            <button className="mt-4 bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700">
              Proceed to Checkout
            </button>
          </div>
        </div>
      ) : (
        <p className="text-xl">Your cart is empty.</p>
      )}
    </div>
  );
}